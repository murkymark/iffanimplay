#include "player_gui.h"


void AnimPlayerGui::threadAppEntry(){
cout << "hello" << endl;

	screen = SDL_SetVideoMode(300, 350, 0, SDL_SWSURFACE | SDL_RESIZABLE);
	if(screen == NULL) {
		cerr << "unable to open SDL video surface: " << SDL_GetError() << endl;
	}

//getchar();
cout << "returning from AnimPlayerGui::threadAppEntry" << endl;
return;
	player->run();
}

void AnimPlayerGui::resizeWindow_user(){
	int h_disp = screen->h;
	if(showGui)
		h_disp -= height;
	player->Resize(screen->w, h_disp);
}

void AnimPlayerGui::myResize(int w_disp, int h_disp){
	if(showGui)
		h_disp += height;
	resizeWindow();
}

void AnimPlayerGui::setupFont(){
	string path = string(exepath) + FONT_FILE;
	
	SDLGuiFont *f;
	f = new SDLGuiFont(SDL_LoadBMP(path.c_str()), "Bitstream Vera Sans Mono");
	if (f->glyphSurf == NULL) {
		cerr << "Error loading font: " << path << endl << SDL_GetError() << endl;
		return;
	}
	SDL_SetColorKey(f->glyphSurf, SDL_SRCCOLORKEY, 0x0); //transparent color black

	//prepare glyphs
	for(int i = 0; i < 256; i++) {
		SDL_Rect r;
		r.x = i * GLYPH_W_BMP;
		r.y = 0;
		r.w = GLYPH_W;
		r.h = GLYPH_H;
		f->glyphRect[i] = r;
	}
	
	addFont(f);
}


void AnimPlayerGui::eventLoop()
{
	cout << "event method" << endl;
/*
 //poll events, empty event queue
 SDL_Event event;
 while(SDL_PollEvent(&event) && !this->signal_appThreadEnd)
 {
	SDL_Delay(eventPollingDelayMs);
	switch(event.type)
	{
		case SDL_QUIT:          //if window is closed
			signal_appThreadEnd = true;
			return;
			break;

		case SDL_VIDEOEXPOSE:
			SDL_Flip(screen);    //redraw screen
			break;

		case SDL_KEYDOWN:      //key event
			switch(event.key.keysym.sym)
			{
				case SDLK_0:
					myResize(player->w_org / 2, player->h_org / 2);
					break;                   
				case SDLK_1:
					myResize(player->w_org, player->h_org);
					break;                          
				case SDLK_2:
					myResize(player->w_org * 2, player->h_org * 2);
					break;                                
				case SDLK_3:
					myResize(player->w_org * 3, player->h_org * 3);
					break;        

				case SDLK_ESCAPE:
					signal_appThreadEnd = true;
					return;
					break;

				case SDLK_SPACE:          //handle pause/play
					if(player->playing == true) {   //stop if currently playing
						if(playAudio) SDL_PauseAudio(1);
						playing = false;
						delayPassed += SDL_GetTicks() - delayWaitStart;  //needed to resynchronize audio when unpausing; must accumulate (multiple pause/unpause during a waiting period possible)
					}
					else {                  //start playing if currently stopped
						playing = true;
						delayWaitStart = SDL_GetTicks();
						delayThres = delayWaitStart + (delayms - delayPassed);  //set threshold to remaining delay when leaving pause mode
						ResetTimer();   //to correct "timerThres"
						SetTimeDelay( (double)(delayms - delayPassed) / 1000.0 );

						if(playAudio) {
							audiopos = queue[qh].apos + ( (int)((double)delayPassed / 1000 * a_srate) * a_frameSize );    //restore audio position (resynchronize)
						}
						QueueFill( minFrameBuf, (int)minAudioBuf );  //prebuffer before starting to play
						if(playAudio) SDL_PauseAudio(0);
					}
					UpdateCaption(); 
					break;
              
				case SDLK_RIGHT:
					if(qframes > 1) { //the next frame must be in the buffer
						audiopos = queue[qh].apos + queue[qh].asize;  // resync audio with next frame
						return IFFANIMPLAY_NONE;                      // leave, so the next frame is displayed immidiately              
					}
					break;

				case SDLK_LEFT:
					if( queue[qh].frameno > 0 )
						if( Seek( queue[qh].frameno - 1 ) )
							return IFFANIMPLAY_NONE;
					break;
          
				case SDLK_r:               // handle reset to first frame; leave on reset and let the main loop load the first frame
					SDL_PauseAudio(1);
					playing = false;         // stop after reset (playing must be enabled manually)
					framecnt = 0;
					ended = false;
					Rewind();
					QueueFree();
					QueueFill( 1, (int)minAudioBuf );   //setup buffer
					ResetTimer(); 
					return IFFANIMPLAY_NONE;
					break;
			   
				case SDLK_g:
					if(gui->showGui)
						gui->showGui = false;
					else
						showGui = true;
					myResize(player->dispimg->w, player->dispimg->h);
					break;
			}
			break; //break SDL_KEYDOWN
		   
		default:
			cerr << "Unknown event received" << endl;
			break;
	}
 }
*/
}


AnimPlayerGui::AnimPlayerGui(SDL_Surface *screen_, string exepath_, AnimPlayer *p) : SDLGui(screen_, exepath_)  {
 //at this point, after the parent constructor is called, screen should be != NULL, if no error occured
return;
 player = p;

 height = 50;
 showGui = true;
 useGL = false;
 
 sliderPos = new Slider;
 sliderPos->setImages("slider0.bmp", "slider1.bmp");
 sliderPos->setMinMax(0, player->numframes - 1);

 buttonPlay = new Button();
 buttonPlay->setImages("control0.bmp", "control1.bmp");
 buttonPause = new Button();
 buttonPause->setImages("control-pause0.bmp", "control-pause1.bmp");
 buttonStop = new Button();
 
 buttonLoop = new Button();
 buttonLoop->setImages("arrow-circle-315-left0.bmp", "arrow-circle-315-left1.bmp");
}

void AnimPlayerGui::render(){
	//for(int i = 0; i < height; i++)
	//  lineH(*screen, 0, i, (*screen)->w, BG_COLOR( ((float)i / (height-1)) ));
	SDL_Rect r = {0, 0, screen->w, this->height};
	SDL_Color bg0 = BG_COLOR_0;
	SDL_Color bg1 = BG_COLOR_1;
	fillRectGradient(screen, &r, 89, bg0, bg1);
	
	buttonPlay->draw(screen, 100, 10);
    buttonPause->draw(screen, 130, 10);
    buttonLoop->draw(screen, 160, 10);
	
	sliderPos->setPos(player->GetFrameIndex());
    sliderPos->draw(screen, 200, 20);
	
    writeText(screen, 0, 2,0, "File: \"abcd/anim\"", 0xff,0xff,0xff);
    writeText(screen, 0, 2,11, "00:00:00.000 / 12:35:57.678", 0xff,0xff,0xff);
}

