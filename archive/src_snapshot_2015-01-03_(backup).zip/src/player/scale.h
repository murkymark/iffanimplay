/// Scale functions, writing scaled source image to destination
/// See *.c file for function descriptions
///
/// Nearest neighbour:
///   the fastest software scaling, uses fixed point integer
///   looks best with exact multiples of original dimension

#ifndef _scale_H_
#define _scale_H_

#include <string.h>
#include <stdint.h>   //for exact integer width



#ifdef __cplusplus
extern "C" {
#endif

void ScaleBitmap8(char *dst, int dstw, int dsth, int dstpitch, char *src, int srcw, int srch, int srcpitch);
void ScaleBitmap24(char *dst, int dstw, int dsth, int dstpitch, char *src, int srcw, int srch, int srcpitch);

#ifdef __cplusplus
} /* closing brace for extern "C" */
#endif


#endif
