// Put system specific code to this file
#include "system_specific.h"

#ifdef OS_WIN
 #include <shellapi.h>
#endif


void system_init(){

	#ifdef OS_WIN
		// Under Windows with the default libSDL apps have no console. This pipes streams to the console again:
		freopen( "CON", "w", stdout );
		freopen( "CON", "w", stderr );
	#endif

}




//drag and drop support, call after window was initialized
void system_window_init(){

  //drag and drop
	#ifdef OS_WIN
    SDL_SysWMinfo wmInfo;
	
    //set SDL version to WMinfo struct
    //-> maybe problems when not calling this macro before
    SDL_VERSION(&wmInfo.version);  

    if(SDL_GetWMInfo(&wmInfo) != SDL_TRUE) {
      cerr << "Error on getting WMInfo" << endl;
      return;
    }
  
    SDL_EventState(SDL_SYSWMEVENT, SDL_ENABLE);
    DragAcceptFiles(wmInfo.window, true);
	#endif
	
}


/*
if (e.type == SDL_SYSWMEVENT)
  system_event_proc(SDL_SysWMmsg *m, *player)
*/
void system_event_proc(SDL_SysWMmsg *m, AnimPlayer *p){

  //process drag and drop event
	#ifdef OS_WIN
    m->hwnd;
    m->msg;
    m->wParam;
    m->lParam;
    
  //When the user releases the mouse button to drop the data, the system calls the target's IDropTarget::Drop method. Among the method's parameters is a pointer to the data object's IDataObject interface.
  //The target calls the data object's IDataObject::GetData method to extract the data.
  
  //extract shell data
  //IDataObject::EnumFormatEtc
	#endif
}

