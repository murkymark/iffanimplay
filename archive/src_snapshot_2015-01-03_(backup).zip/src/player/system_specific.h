// system specific declarations and code

#ifndef _system_specific_H_
#define _system_specific_H_

#include <cstdio>
#include <iostream>

#include <SDL/SDL.h>
#include <SDL/SDL_syswm.h>

#include "player.h"

using namespace std;


/// OS to compile for
#define OS_WIN
//#define OS_LINUX



//system dependant init
void system_init();

//system dependant init
//call only after window is opened, or resized (may crash otherwise)
void system_window_init();

//process system events (drag and drop)
void system_event_proc();

#endif
